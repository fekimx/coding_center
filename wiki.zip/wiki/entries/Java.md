# Java

Java was developed by James Gosling at Sun Microsystems.